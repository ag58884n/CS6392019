package com.example.uisummer1.ui.mainactivity2;

import android.arch.lifecycle.ViewModel;

public class MainActivity2ViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
